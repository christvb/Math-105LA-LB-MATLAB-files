function [y,q] = chebyshev(f,N,x)   
% f = function handle to be approximated 
% N = degree of the Chebyshev polynomial, P(x) 
% x = x-coordinate to calculate P(x) 
% y = P(x)
% q = P(x) (as a function handle)

%% approxiating a_0 term
T0=@(x)cos(0*acos(x));
S0=@(z)cos(0*z); % substituting x=cos(z)

g=@(z)((2/pi)*f(cos(z))*S0(z));
h=(pi-0)/1000;
ZI0=g(0)+g(pi);
ZI1=0;
ZI2=0;
for i=1:1000
    Z=0+i*h;
    if (mod(i,2)==0)
        ZI2=ZI2+g(Z);
    else
        ZI1=ZI1+g(Z);
    end
end
ZI=h*(ZI0+2*ZI2+4*ZI1)/3;
w0=ZI;% numerator

k=@(z)(S0(z))^2;
h=(pi-0)/1000;
ZI0=k(0)+k(pi);
ZI1=0;
ZI2=0;
for i=1:1000
    Z=0+i*h;
    if (mod(i,2)==0)
        ZI2=ZI2+k(Z);
    else
        ZI1=ZI1+k(Z);
    end
end
ZI=h*(ZI0+2*ZI2+4*ZI1)/3;
v0=ZI;% denominator
a0=w0/v0;
q=@(x)a0*T0(x);

%% approximating a_1 to a_N terms
for j=1:N
T=@(x)cos(j*acos(x));
S=@(z)cos(j*z); % substituting x=cos(z)

g=@(z)(f(cos(z))*S(z));
h=(pi-0)/1000;
ZI0=g(0)+g(pi);
ZI1=0;
ZI2=0;
for i=1:1000
    Z=0+i*h;
    if (mod(i,2)==0)
        ZI2=ZI2+g(Z);
    else
        ZI1=ZI1+g(Z);
    end
end
ZI=h*(ZI0+2*ZI2+4*ZI1)/3;
w(j)=ZI;% numerator

k=@(z)(S(z))^2;
h=(pi-0)/1000;
ZI0=k(0)+k(pi);
ZI1=0;
ZI2=0;
for i=1:1000
    Z=0+i*h;
    if (mod(i,2)==0)
        ZI2=ZI2+k(Z);
    else
        ZI1=ZI1+k(Z);
    end
end
ZI=h*(ZI0+2*ZI2+4*ZI1)/3;
v(j)=ZI;% denominator
a(j)=w(j)/v(j);
q=@(x)q(x)+a(j)*T(x);
end

%% final P(x)
y=q(x);
end