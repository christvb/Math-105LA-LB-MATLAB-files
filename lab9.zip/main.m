%% N=2

% Computing Chebyshev polynomial of e^x over [-1,1]
f=@(x)exp(x);
X=linspace(-1,1,1000);
N=2;
M(1)=N;
Y1=chebyshev(f,N,X) % Chebyshev polynomial of e^x for N=2

% Calculating error
x=1;
[y,q]=chebyshev(f,N,x);
m=@(z)abs(q(cos(z))-f(cos(z)))^2;
h=(pi-0)/1000;
ZI0=m(0)+m(pi);
ZI1=0;
ZI2=0;
for i=1:1000
    Z=0+i*h;
    if (mod(i,2)==0)
        ZI2=ZI2+m(Z);
    else
        ZI1=ZI1+m(Z);
    end
end
ZI=h*(ZI0+2*ZI2+4*ZI1)/3;
E(1)=ZI; % error for N=2

%% N=3

% Computing Chebyshev polynomial of e^x over [-1,1]
f=@(x)exp(x);
X=linspace(-1,1,1000);
N=3;
M(2)=N;
Y2=chebyshev(f,N,X) % Chebyshev polynomial of e^x for N=3

% Calculating error
x=1;
[y,q]=chebyshev(f,N,x);
m=@(z)abs(q(cos(z))-f(cos(z)))^2;
h=(pi-0)/1000;
ZI0=m(0)+m(pi);
ZI1=0;
ZI2=0;
for i=1:1000
    Z=0+i*h;
    if (mod(i,2)==0)
        ZI2=ZI2+m(Z);
    else
        ZI1=ZI1+m(Z);
    end
end
ZI=h*(ZI0+2*ZI2+4*ZI1)/3;
E(2)=ZI; % error

%% N=4

% Computing Chebyshev polynomial of e^x over [-1,1]
f=@(x)exp(x);
X=linspace(-1,1,1000);
N=4;
M(3)=N;
Y3=chebyshev(f,N,X) % Chebyshev polynomial of e^x for N=4

% Calculating error
x=1;
[y,q]=chebyshev(f,N,x);
m=@(z)abs(q(cos(z))-f(cos(z)))^2;
h=(pi-0)/1000;
ZI0=m(0)+m(pi);
ZI1=0;
ZI2=0;
for i=1:1000
    Z=0+i*h;
    if (mod(i,2)==0)
        ZI2=ZI2+m(Z);
    else
        ZI1=ZI1+m(Z);
    end
end
ZI=h*(ZI0+2*ZI2+4*ZI1)/3;
E(3)=ZI; % error

%% N=5

% Computing Chebyshev polynomial of e^x over [-1,1]
f=@(x)exp(x);
X=linspace(-1,1,1000);
N=5;
M(4)=N;
Y4=chebyshev(f,N,X) % Chebyshev polynomial of e^x for N=4

% Calculating error
x=1;
[y,q]=chebyshev(f,N,x);
m=@(z)abs(q(cos(z))-f(cos(z)))^2;
h=(pi-0)/1000;
ZI0=m(0)+m(pi);
ZI1=0;
ZI2=0;
for i=1:1000
    Z=0+i*h;
    if (mod(i,2)==0)
        ZI2=ZI2+m(Z);
    else
        ZI1=ZI1+m(Z);
    end
end
ZI=h*(ZI0+2*ZI2+4*ZI1)/3;
E(4)=ZI; % error

%% Plotting error as a function of N
figure
plot(M,E,'o')