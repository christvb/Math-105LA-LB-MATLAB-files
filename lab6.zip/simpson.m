function XI=simpson(f,a,b,n)
% f=function handle to be integrated 
% a,b=the integral endpoints 
% n=number of subintervals, must be an even integer 
% f=@(x)cos(x)/x;n=100;a=1;b=5;simpson(f,a,b,n)
% f=@(x)-1+3*x+(x)^2;n=100;a=-1;b=3;simpson(f,a,b,n)
% f=@(x)exp((-(x)^2));n=100;a=0;b=10;simpson(f,a,b,n)
% f=@(x)1/(4+x^2);n=100;a=-10;b=10;simpson(f,a,b,n)
% f=@(x)log(1+x);n=100;a=0;b=2;simpson(f,a,b,n)
h=(b-a)/n;
XI0=f(a)+f(b);
XI1=0;
XI2=0;
for i=1:n-1
    X=a+i*h;
    if (mod(i,2)==0)
        XI2=XI2+f(X);
    else
        XI1=XI1+f(X);
    end
end
XI=h*(XI0+2*XI2+4*XI1)/3;
end 