function XI=trapezoidal(f,a,b,n)
% f=function handle to be integrated 
% a,b=the integral endpoints 
% n=number of subintervals 
% f=@(x)cos(x)/x;n=100;a=1;b=5;trapezoidal(f,a,b,n)
% f=@(x)-1+3*x+(x)^2;n=100;a=-1;b=3;trapezoidal(f,a,b,n)
% f=@(x)exp((-(x)^2));n=100;a=0;b=10;trapezoidal(f,a,b,n)
% f=@(x)1/(4+x^2);n=100;a=-10;b=10;trapezoidal(f,a,b,n)
% f=@(x)log(1+x);n=100;a=0;b=2;trapezoidal(f,a,b,n)
h=(b-a)/n;
XI0=f(a)+f(b);
XI1=0;
for i=1:n-1
    X=a+i*h;
    XI1=XI1+f(X);
end
XI=h*(XI0+2*XI1)/2;
end 
