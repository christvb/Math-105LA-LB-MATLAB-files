function y = lagrange(X,Y,x)
% X = input coordinates 
% Y = corresponding function values 
% x = interpolation point x 
% y = interpolated function value at x, i.e. P(x) 
% your implementation below 
y=0;
for i=1:length(X)
    r=1;
    for j=1:length(X)
        if j~=i
            q=(x-X(j))/(X(i)-X(j));
            r=r*q;
        end
    end
y=y+Y(i)*r
end 