%% a) 
n=50;
[Ypf,Ypb,Ypc,Yp]=deriv(n);
x=linspace(-3,3,n-1);
figure
plot(x,Ypf,'b')
hold on
plot(x,Ypb,'r')
plot(x,Ypc,'y')
plot(x,Yp,'m')

%% 
n=100;
[Ypf,Ypb,Ypc,Yp]=deriv(n);
x=linspace(-3,3,n-1);
figure
plot(x,Ypf,'b')
hold on
plot(x,Ypb,'r')
plot(x,Ypc,'y')
plot(x,Yp,'m')

%%
n=200;
[Ypf,Ypb,Ypc,Yp]=deriv(n);
x=linspace(-3,3,n-1);
figure
plot(x,Ypf,'b')
hold on
plot(x,Ypb,'r')
plot(x,Ypc,'y')
plot(x,Yp,'m')

%% b) 
n=50;
[Ypf,Ypb,Ypc,Yp]=deriv(n);
ef=zeros(1,n);
Ef=zeros(1,4);
%forward difference error for n=50
for i=1:n-1
    ef(i)=abs(Yp(i)-Ypf(i));
end
Ef(1)=max(ef);
%backward difference error for n=50
eb=zeros(1,n);
Eb=zeros(1,4);
for i=1:n-1
    eb(i)=abs(Yp(i)-Ypb(i));
end
Eb(1)=max(eb);
%central difference error for n=50
ec=zeros(1,n);
Ec=zeros(1,4);
for i=1:n-1
    ec(i)=abs(Yp(i)-Ypc(i));
end
Ec(1)=max(ec);

%%
n=100;
[Ypf,Ypb,Ypc,Yp]=deriv(n);
ef=zeros(1,n);
%forward difference error for n=100
for i=1:n-1
    ef(i)=abs(Yp(i)-Ypf(i));
end
Ef(2)=max(ef);
%backward difference error for n=100
eb=zeros(1,n);
for i=1:n-1
    eb(i)=abs(Yp(i)-Ypb(i));
end
Eb(2)=max(eb);
%central difference error for n=100
ec=zeros(1,n);
for i=1:n-1
    ec(i)=abs(Yp(i)-Ypc(i));
end
Ec(2)=max(ec);

%%
n=200;
[Ypf,Ypb,Ypc,Yp]=deriv(n);
ef=zeros(1,n);
%forward difference error for n=200
for i=1:n-1
    ef(i)=abs(Yp(i)-Ypf(i));
end
Ef(3)=max(ef);
%backward difference error for n=200
eb=zeros(1,n);
for i=1:n-1
    eb(i)=abs(Yp(i)-Ypb(i));
end
Eb(3)=max(eb);
%central difference error for n=200
ec=zeros(1,n);
for i=1:n-1
    ec(i)=abs(Yp(i)-Ypc(i));
end
Ec(3)=max(ec);

%%
n=500;
[Ypf,Ypb,Ypc,Yp]=deriv(n);
ef=zeros(1,n);
%forward difference error for n=500
for i=1:n-1
    ef(i)=abs(Yp(i)-Ypf(i));
end
Ef(4)=max(ef);
%backward difference error for n=500
eb=zeros(1,n);
for i=1:n-1
    eb(i)=abs(Yp(i)-Ypb(i));
end
Eb(4)=max(eb);
%central difference error for n=500
ec=zeros(1,n);
for i=1:n-1
    ec(i)=abs(Yp(i)-Ypc(i));
end
Ec(4)=max(ec);

%%
N=[50,100,200,500];

%Ef contains the maximum forward difference errors
figure
plot(N,transpose(Ef),'-o')
plot(log(N),log(Ef),'-o')
polyfit(log(N),log(Ef),1)

%Eb contains the maximum backward difference errors
figure
plot(N,transpose(Eb),'-o')
plot(log(N),log(Eb),'-o')
polyfit(log(N),log(Eb),1)

%Ec contains the maximum central difference errors
figure
plot(N,transpose(Ec),'-o')
plot(log(N),log(Eb),'-o')
polyfit(log(N),log(Ec),1)

%% c)
n=50;
[Yp,Yps]=deriv(n);
x=linspace(-3,3,n-1);
figure
plot(x,Yps,'g')

es=zeros(1,n);
%second-order central difference error for n=50
for i=1:n-1
    es(i)=abs(Yp(i)-Yps(i));
end
Es(1)=max(es);

%% 
n=100;
[Yp,Yps]=deriv(n);
x=linspace(-3,3,n-1);
figure
plot(x,Yps,'g')

es=zeros(1,n);
%second-order central difference error for n=100
for i=1:n-1
    es(i)=abs(Yp(i)-Yps(i));
end
Es(2)=max(es);

%% 
n=200;
[Yp,Yps]=deriv(n);
x=linspace(-3,3,n-1);
figure
plot(x,Yps,'g')

es=zeros(1,n);
%second-order central difference error for n=200
for i=1:n-1
    es(i)=abs(Yp(i)-Yps(i));
end
Es(3)=max(es);

%% 
n=500;
[Yp,Yps]=deriv(n);

es=zeros(1,n);
%second-order central difference error for n=500
for i=1:n-1
    es(i)=abs(Yp(i)-Yps(i));
end
Es(4)=max(es);

%%
N=[50,100,200,500];

%Es contains the maximum second-order central difference errors
figure
plot(N,transpose(Es),'-o')
plot(log(N),log(Es),'-o')
polyfit(log(N),log(Es),1)

%%
function [Ypf,Ypb,Ypc,Yp,Yps]=deriv(n)
h=6/n;
X=zeros(1,n);
Y=zeros(1,n);
for i=1:n
    X(i)=-3+i*h;%x_i
end
for i=1:n
    Y(i)=X(i)/(0.25+(X(i))^2);%f(x_i)
end
% forward difference
Ypf=zeros(1,n-1);
for i=1:n-1
   Ypf(i)=(Y(i+1)-Y(i))/h;%f'(x_i) approximation using forward difference
end
% backward difference
Ypb=zeros(1,n-1);
Z=(-3)/(0.25+(-3)^2);%f(x_0)
Ypb(1)=(Y(1)-Z)/h;
for i=2:n-1
    Ypb(i)=(Y(i)-Y(i-1))/h;%f'(x_i) approximation using backward difference
end
% central difference
Ypc=zeros(1,n-1);
Ypc(1)=(1/(2*h))*(Y(2)-Z);
for i=2:n-1
    Ypc(i)=(1/(2*h))*(Y(i+1)-Y(i-1));%f'(x_i) approximation using central difference
end
% actual f'(x)
Yp=zeros(1,n-1);
for i=1:n-1
    Yp(i)=1/((X(i))^2+1/4)-(2*(X(i))^2)/((X(i))^2+1/4)^2;%f'(x_i)
end
% second-order central difference
Yps=zeros(1,n-1);
Yps(1)=(1/(h^2))*(Y(2)-Z-2*Y(1));
for i=2:n-1
    Yps(i)=(1/(h^2))*(Y(i+1)-Y(i-1)-2*Y(i));%f''(x_i) approximation using second-order central difference
end
end