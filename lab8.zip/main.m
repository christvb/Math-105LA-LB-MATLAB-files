f=@(x)(1+tanh(5*(x-3)))/2;
a=0;
b=5;
level=0;
N=20;
eps=(10^(-5));
adaptive_gauss(f,a,b,level,N,eps)