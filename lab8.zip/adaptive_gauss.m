function [sum]=adaptive_gauss(f,a,b,level,N,eps)
% sum = approximation to the integral
% f = function handle to be integrated 
% a,b = the integral endpoints
% eps = the tolerance
% level = current level of refinement
% N = max level
% f=@(x)(1+tanh(5*(x-3)))/2;a=0;b=5;N=20;eps=(10^(-5));adaptive_gauss(f,a,b,level,N,eps)
one_gauss=gauss(f,a,b);
c=(a+b)/2;
two_gauss=gauss(f,a,c)+gauss(f,c,b);
if level>N
    fprintf('Error: max level reached')
    sum=two_gauss;
else
    if abs(one_gauss-two_gauss)<eps
        sum=two_gauss;
    else
        sum1=adaptive_gauss(f,a,c,level+1,N,eps);
        sum2=adaptive_gauss(f,c,b,level+1,N,eps);
        sum=sum1+sum2;
    end
    fprintf('[%0.6f,%0.6f] contribution=%0.6f level=%0.0f',a,b,sum,level)
end
end