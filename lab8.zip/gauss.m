function [APP]=gauss(f,a,b)
% APP = numerical integral
% f = function handle to be integrated 
% a,b = the integral endpoints 
t=-sqrt(3)/3;
s=sqrt(3)/3;
g=((b-a)*t+(b+a))/2;
h=((b-a)*s+(b+a))/2;
j=(b-a)/2;
APP=j*(f(g)+f(h));
end