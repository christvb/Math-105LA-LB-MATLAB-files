x=linspace(-2.4,2.4,100); 

%f(x)
z=zeros(1,100);
for i = 1:100     
    z(i)=(x(i))/(0.25+(x(i))^2);
end

%cubic spline
X=[-2.4061;-1.0830;-0.6440;-0.4068;-0.2448;-0.1158;0;0.1158;0.2448;0.4068;0.6440;1.0830;2.4061];
Y=[-0.3984;-0.7611;-0.9688;-0.9791;-0.7899;-0.4397;0;0.4397;0.7899;0.9791;0.9688;0.7611;0.3984];
y=zeros(1,100);
for i = 1:100     
    y(i) = cubic_spline(X,Y,x(i));
end

figure %create a new figure 
plot(x,z,'b') %plot the actual function f(x) in blue
hold on %plot multiple curves on the same figure 
plot(x,y,'r') % plot cubic spline 

%lagrangeplot
%X=[-2.4061;-1.0830;-0.6440;-0.4068;-0.2448;-0.1158;0;0.1158;0.2448;0.4068;0.6440;1.0830;2.4061];
%Y=[-0.3984;-0.7611;-0.9688;-0.9791;-0.7899;-0.4397;0;0.4397;0.7899;0.9791;0.9688;0.7611;0.3984];
%x=linspace(-2.4,2.4,100); 
%p=zeros(1,100); 
%for i = 1:100     
%    p(i) = lagrange(X,Y,x(i));
%end
%figure
%plot(x,p) 