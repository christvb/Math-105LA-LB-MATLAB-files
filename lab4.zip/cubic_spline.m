function y = cubic_spline(X,Y,x)
% X = numbers x_1 x_2 ... x_n
% Y = values f(x_1) f(x_2) ... f(x_n)
% x = interpolation point x
% y = spline value at x, i.e. S(x)
% X and Y are column vectors
% X=[-2.4061;-1.0830;-0.6440;-0.4068;-0.2448;-0.1158;0;0.1158;0.2448;0.4068;0.6440;1.0830;2.4061];
% Y=[-0.3984;-0.7611;-0.9688;-0.9791;-0.7899;-0.4397;0;0.4397;0.7899;0.9791;0.9688;0.7611;0.3984];
m=size(X);
n=m(1,1)-1;
for i=1:n
    h(i)=X(i+1)-X(i);
end
for i=2:n
    alpha(i)=3/h(i)*(Y(i+1)-Y(i))-3/h(i-1)*(Y(i)-Y(i-1));
end
l(1)=1;
mu(1)=0;
z(1)=0;
for i=2:n
    l(i)=2*(X(i+1)-X(i-1))-h(i-1)*mu(i-1);
    mu(i)=h(i)/l(i);
    z(i)=(alpha(i)-h(i-1)*z(i-1))/l(i);
end
l(n+1)=1;
z(n+1)=0;
c(n+1)=0;
for j=n:-1:1
    c(j)=z(j)-mu(j)*c(j+1);
    b(j)=(Y(j+1)-Y(j))/h(j)-h(j)*(c(j+1)+2*c(j))/3;
    d(j)=(c(j+1)-c(j))/(3*h(j));
end
b(n+1)=0;
d(n+1)=0;
for j=1:n
    if (X(j)<=x)&&(x<=X(j+1))
        y=Y(j)+b(j)*(x-X(j))+c(j)*((x-X(j))^2)+d(j)*((x-X(j))^3);
    end
end
end