%% f(x)=(1+tanh(5*x))/2;
f=@(x)(1+tanh(5*x))/2;
a=-2.9;
b=3;
TOL=5*10^(-6);
N=20;
[APP,pts]=adaptive_simpson(f,a,b,TOL,N);
app1=APP

figure 
fplot(f,[a,b])
hold on

m=size(pts);
n=m(1,2);
p=zeros(1,n);
for i=1:n     
    p(i)=(1+tanh(5*pts(i)))/2;
end
plot(pts,p,'o')

%% f(x)=1/(1+x)
f=@(x)1/(1+x);
a=1;
b=100;
TOL=10^(-4);
N=20;
[APP,pts]=adaptive_simpson(f,a,b,TOL,N);
app2=APP

figure 
fplot(f,[a,b])
hold on

m=size(pts);
n=m(1,2);
q=zeros(1,n);
for i=1:n     
    q(i)=1/(1+pts(i));
end
plot(pts,q,'o')

%% f(x)=log(x)
f=@(x)log(x);
a=0.1;
b=10;
TOL=10^(-4);
N=20;
[APP,pts]=adaptive_simpson(f,a,b,TOL,N);
app3=APP

figure 
fplot(f,[a,b])
hold on

m=size(pts);
n=m(1,2);
r=zeros(1,n);
for i=1:n     
    r(i)=log(pts(i));
end
plot(pts,r,'o')

%% f(x)=exp(-1/(1+x^2))
f=@(x)exp(-1/(1+x^2));
a=-40;
b=40;
TOL=10^(-4);
N=20;
[APP,pts]=adaptive_simpson(f,a,b,TOL,N);
app4=APP

figure 
fplot(f,[a,b])
hold on

m=size(pts);
n=m(1,2);
s=zeros(1,n);
for i=1:n     
    s(i)=exp(-1/(1+(pts(i))^2));
end
plot(pts,s,'o')